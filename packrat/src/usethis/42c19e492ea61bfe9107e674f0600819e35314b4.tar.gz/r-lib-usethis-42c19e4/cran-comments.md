## Test environments
* local OS X install, R-release
* ubuntu 14.04 (on travis-ci), R 3.1 -> R-devel
* win-builder (R-devel)

## R CMD check results

0 errors | 0 warnings | 0 notes

## revdepcheck results

We checked 1 reverse dependency (testthis), comparing R CMD check results across CRAN and dev versions of this package. We see no problems.
