
print_out <- function(x, ...) {
  lines <- m(y, ..., print = TRUE)
  paste(lines, sep = "\n")
}

# No comment

kng <- function(x, y) spm(fmt = "%i", lgd(x), tds(y))
tka <- function(my, y) ttt(gmks = "%s", slice(x), acast(d))

another <- function(x, y) {
  if (!fun(x) && !not_is(y)) {
    return(s)
  }
  identical(kss(nmp), gsk(rdm))
}
