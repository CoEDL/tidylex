if(TRUE)NULL

if(TRUE)NULL # comment


if(TRUE) # comment
NULL

if(TRUE # comment
)NULL

if( # comment
TRUE)NULL

if # comment
(TRUE)NULL
