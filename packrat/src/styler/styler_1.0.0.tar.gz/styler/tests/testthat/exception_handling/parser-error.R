b <- call() {
  d
}
