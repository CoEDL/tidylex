# random
this(is_a_call(x))
if (x) {
  r()
  a    <- 3
  bcds <- 5
}
