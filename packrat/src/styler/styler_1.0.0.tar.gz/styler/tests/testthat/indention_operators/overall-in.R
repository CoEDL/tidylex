pd%>%
mutate(x =devide(call3(a, b, 1 + q))) %>%
     filter( !terminal) %>%
  ggplot(aes(x = new, y = old))+
geom_point()

1+(
22- (1/
  2718 /
    23* 29 * (
            2     * (22*-1) +
              1)     -
          18) +
    sin(    pi) -
2
  )

a <- function(z) {
  a %>%
    q() %>%
    n()
}

 a %>%
b()%>%
c()%>%
k()
