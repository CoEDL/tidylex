a ||
  b

a >
  4

a &
  3

b %in%
  c

data_frame(
  a =
    list()
)
b =
  3
