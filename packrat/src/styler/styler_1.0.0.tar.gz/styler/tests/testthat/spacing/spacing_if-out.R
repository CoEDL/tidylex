if (TRUE) x else y
