as_unknown <- function(x) {
  Encoding(x) <- "unknown"
  x
}
