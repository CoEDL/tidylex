library(testthat)
library(enc)

test_check("enc")
